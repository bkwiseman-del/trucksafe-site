import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import bcrypt from "bcryptjs"

// This is a placeholder - you'll replace with your actual database
// For now, simulating with in-memory data
const users = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    password: await bcrypt.hash("password123", 10), // In real app, already hashed in DB
    access: {
      networkMember: true,
      complianceMember: {
        tier: "pro",
        status: "active"
      },
      bootcampAttendee: {
        year: 2026,
        status: "attended"
      },
      academyAccess: true
    }
  }
]

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        // TODO: Replace with your database query
        const user = users.find(u => u.email === credentials.email)
        
        if (!user) {
          return null
        }

        const isValid = await bcrypt.compare(credentials.password, user.password)
        
        if (!isValid) {
          return null
        }

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          access: user.access
        }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.access = user.access
      }
      return token
    },
    async session({ session, token }) {
      if (token.access) {
        session.user.access = token.access
      }
      return session
    }
  },
  pages: {
    signIn: '/login',
  },
  session: {
    strategy: "jwt"
  }
})
